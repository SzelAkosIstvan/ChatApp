
<?php
include "db.php";
$sql2 = "SELECT user_id, unique_id, fname, lname, img from users WHERE unique_id = $nr";
            $result2 = $conn-> query($sql2);
            if($result2->num_rows==1){
                while($row = $result2-> fetch_assoc()){
                    $_SESSION['img']=$row['img'];
                    echo '
<div class="inf">
                <h1>'.$row["fname"].' '.$row["lname"].'</h1>
            </div>
            
                <div class="profilenochat">
                    <img class="profilenochatimg" src="profile/'.$row["img"].'" alt="">
                    <h1>'.$row["fname"].' '.$row["lname"].'</h1>
                    <button>Add friend</button>
                </div>
                <div id="refr" style="height:fit-content;">
                ';
                $sql3 = "SELECT msg_from, msg_to, msg_information from message where msg_from=$nr && msg_to=$me or msg_from=$me && msg_to=$nr";
                $result3 = $conn-> query($sql3);
                if($result3->num_rows>0){
                    while($row = $result3-> fetch_assoc()){
                        if($row['msg_from'] = $nr && $row['msg_to'] = $me && $row['msg_from'] != $me && $row['msg_to'] != $nr)
                        {if(substr($row["msg_information"], -4)==".png" or substr($row["msg_information"], -4)==".jpg" or substr($row["msg_information"], -4)==".jpeg" or substr($row["msg_information"], -4)==".gif")
                            {echo '
                                <div class="friendchat" id="friendchat">
                                    <img src="profile/'.$_SESSION['img'].'" class="friendprof">
                                    <p class="friendtext">
                                    <img src="images/'.$row["msg_information"].'" style="height:100px;">
                                    </p>
                                </div>';}
                            else{
                                echo '
                        <div class="friendchat" id="friendchat">
                            <img src="profile/'.$_SESSION['img'].'" class="friendprof">
                            <p class="friendtext">
                                '.$row["msg_information"].'
                            </p>
                        </div>';
                            }
                            
                        }
                        if($row['msg_from'] = $me && $row['msg_to'] = $nr && $row['msg_from'] != $nr && $row['msg_to'] != $me)
                        {
                            if(substr($row["msg_information"], -4)==".png" or substr($row["msg_information"], -4)==".jpg" or substr($row["msg_information"], -4)==".jpeg" or substr($row["msg_information"], -4)==".gif")
                            {echo '
                            <div class="mychat">
                                <p class="mytext">
                                    <img src="images/'.$row["msg_information"].'" style="height:100px;">
                                </p>
                            </div>';}
                            elseif(substr($row["msg_information"], -4,1)=="."){
                                echo '
                            <div class="mychat">
                                <p class="mytext">
                                    <a href="files/'.$row["msg_information"].'" download  style="color:black; text-decoration:none; display:flex; flex-direction:column;  justify-content:center; align-items:center;">
                                        <img src="files.png" style="height:40px;">
                                        '.$row["msg_information"].'
                                    </a>
                                </p>
                            </div>';
                            }
                            else{
                                echo '
                            <div class="mychat">
                                <p class="mytext">
                                    '.$row["msg_information"].'
                                </p>
                            </div>';
                            }}}
                        }
                        echo '
        </div></div>
        <div class="msg_send">
            <div class="centr">
                <button class="clip" onclick="hidemmsg()">
                <img src="paperclip-solid.svg" alt="">
                </button>
                <div class="sendmtmsg" id="sendmtmsg">
                    <button onclick="document.getElementById(`myImageInput`).click()"><img src="image-gallery.png" alt=""><p>Images</p></button>
                    <button onclick="document.getElementById(`myFileInput`).click()"><img src="files.png" alt=""><p>Files</p></button>
                    <button onclick="openreactionmenu()"><img src="reaction.png" alt=""><p>Reaction</p></button>
                </div>
                <div class="reactionmenu" id="reactionmenu">
                    <img src="laughing.png" onclick="sendmoji(`laughing.png`)">
                    <img src="happy.png" onclick="sendmoji(`happy.png`)">
                    <img src="cute.png" onclick="sendmoji(`cute.png`)">
                    <img src="likeeye.png" onclick="sendmoji(`likeeye.png`)">
                    <img src="crazy.png" onclick="sendmoji(`crazy.png`)">
                    <img src="shocked.png" onclick="sendmoji(`shocked.png`)">
                    <img src="angry.png" onclick="sendmoji(`angry.png`)">
                    <img src="sad.png" onclick="sendmoji(`sad.png`)">
                    <img src="wink.png" onclick="sendmoji(`wink.png`)">
                    <img src="heart.png" onclick="sendmoji(`heart.png`)">
                </div>
                <form method="POST" action="msg_send.php" id="text">
                    <input type="text" name="your_msg" autocomplete="off" id="write">
                    <input type="text" style="display: none;" value="'.$me.'" name="myid">
                    <input type="text" style="display: none;" value="'.$nr.'" name="friendid">
                    <button type="submit">
                        <img src="paper-plane-solid.svg" alt="">
                    </button>
                </form>
                <form method="POST" action="img_send.php" id="sendimage" enctype="multipart/form-data">
                    <input type="file" name="your_img" id="myImageInput" accept="image/gif, image/jpeg, image/png" onchange="readURL(this);" style="display: none;">
                    <input type="text" style="display: none;" value="'.$me.'" name="myid">
                    <input type="text" style="display: none;" value="'.$nr.'" name="friendid">
                    <div class="sendimage">
                        <img id="blah" src="#">
                        <button id="blahx" type="checkbox" style="display: none;"></button>
                        <img src="close.png" id="closesend" onclick="returntowritre()">
                    </div>
                    <button type="submit">
                        <img src="paper-plane-solid.svg" alt="">
                    </button>
                </form>
                <form method="POST" action="file_send.php"  id="sendfile" enctype="multipart/form-data">
                    <input type="file" name="your_file" id="myFileInput"  style="display: none;" onchange="readFILE(this);">
                    <input type="text" style="display: none;" value="'.$me.'" name="myid">
                    <input type="text" style="display: none;" value="'.$nr.'" name="friendid">
                    <div class="sendfile">
                        <img id="filesend" src="files.png">
                        <p id="filename">Your file is loaded</p>
                        <button id="blahy" type="checkbox" style="display: none;"></button>
                        <img src="close.png" id="closesend" onclick="returntowritre()">
                    </div>
                    <button type="submit">
                        <img src="paper-plane-solid.svg" alt="">
                    </button>
                </form>
            </div>
        </div>';}}
?>