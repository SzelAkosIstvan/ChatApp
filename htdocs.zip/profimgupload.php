<?php
session_start();
$_SESSION['chat']= $_POST['link'];
$_SESSION['status']= "Done";
include "db.php";
if(isset($_POST['myid']))
{
    $extension=array('jpeg', 'jpg', 'png', 'gif');
        $filename=$_FILES['profimg']['name'];
        $filename_tmp=$_FILES['profimg']['tmp_name'];
        $ext=pathinfo($filename,PATHINFO_EXTENSION);
        $finalimg='';
        if(in_array($ext, $extension)){
            if(!file_exists('profile/'.$filename)){
            move_uploaded_file($filename_tmp, 'profile/'.$filename);
            $finalimg=$filename;
            }else{
                $filename=str_replace('.','-',basename($filename,$ext));
                $newfilename=$filename.time().".".$ext;
                move_uploaded_file($filename_tmp, 'profile/'.$newfilename);
                $finalimg=$newfilename;
            }
            $me = $_SESSION['unique_id'];
            $_SESSION['img']=$finalimg;
            $updateqry="UPDATE `users` SET `img`='$finalimg',`status`='Done' WHERE `unique_id`='$me'";
            mysqli_query($conn, $updateqry);
            header('Location: index.php');
        }else{

        }
    }
?>