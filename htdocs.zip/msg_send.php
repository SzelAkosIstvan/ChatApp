<?php
session_start();
include "db.php";
    if (isset($_POST['your_msg']) && isset($_POST['myid']) && isset($_POST['friendid'])){
        function validate($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        $y_msg = validate($_POST['your_msg']);
        $m_name = validate($_POST['myid']);
        $f_name = validate($_POST['friendid']);
        $time_temp = date("Y m d/h:i:sa");
        if(empty($y_msg)){
            header("Location: index.php");
            exit();
        }else{
            $sql="INSERT INTO message(msg_from, msg_to, msg_information, msg_time) VALUES('$m_name','$f_name','$y_msg','$time_temp')";
            $result = mysqli_query($conn, $sql);
            header("Location: index.php");
            exit();
        }
    }else{
        header("Location: index.php");
        exit();
    }
?>