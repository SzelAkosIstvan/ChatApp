<?php
include "db.php";
session_start();
$nr=$_SESSION['chat'];
if(isset($_SESSION['user_id']) && isset($_SESSION['unique_id']) && isset($_SESSION['fname']) && isset($_SESSION['lname']) && isset($_SESSION['img']) && isset($_SESSION['status']) && isset($nr)){

    $me=$_SESSION['unique_id'];
    $sql = "SELECT user_id, unique_id, fname, lname, img from users";
    $result = $conn-> query($sql);
$condition = "unique_id = '$me'";
$dsasafd = "SELECT * FROM users WHERE $condition LIMIT 1";
$fhgrserwga = mysqli_query($conn, $dsasafd);
if (mysqli_num_rows($fhgrserwga) > 0) {
    $sda = mysqli_fetch_assoc($fhgrserwga);
    $my_var = $sda['img'];
} else {
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IdealChat</title>
    <link rel="stylesheet" href="index.css">
</head>
<body onload="scrollToBottom">
    <!--<div class="menu">
        <div class="head">
            <img src="bars-solid.svg">
        </div>
    </div>-->
    <div class="main">
        <div class="header">
            <div class="logo">
                    <form action="changeview.php" method="post" style="width:fit-content; height:fit-content;">
                    <button name="link" id="link" value="none" style="background:none; border:none; width:fit-content; height:fit-content;">
                <img src="output-onlinepngtools.png" style="height: 50px;margin-left: 70px;margin-right: 30px; cursor:pointer;">
                <h1 style="cursor:pointer;">Chat</h1>
                    </button>
                    </form>
            </div>
            <div class="other">
                    <!--<input class="search" type="text">
                <button class="search-btn" class="search">
                    <img src="magnifying-glass-solid.svg" style="width: 15px;height: 15px;">
                </button>
                <button class="notif" style="background-color: transparent;border: none;width: 50px;height: 50px;margin-left: 30px;">
                    <img src="bell-solid.svg" style="width: 30px;height: 30px;cursor: pointer;" onclick="hidenotifs()">
                    <div class="notification" id="notification" style="cursor: pointer;" onclick="hidenotifs()"></div>
                </button>-->
                <img src="profile/<?php echo $my_var; ?>"  onclick="hidesettings()" class="profile" style="width:50px; height:50px; border-radius:50%; border:none; cursor:pointer;margin-right: 70px;margin-left: 30px;object-fit: cover;">
            </div>
        </div>
        <!-- valtozik majd a link miatt -->
        <?php 
        if($_SESSION['status'] == 'New') 
        echo '
        <div class="sometimes">
            <div class="settings_panel">
                <h1>Final step</h1>
                <form action="profimgupload.php" method="post" enctype="multipart/form-data">
                    <input id="profimg" name="profimg" type="file" accept="image/png,image/jpeg,image/jpg" style="display:none";>
                    <input type="text" style="display: none;" value="'.$me.'" name="myid">
                    <input name="link" id="link" value="none" style="display: none;">
                    <button name="finishreg" id="finishreg" type="submit">Upload</button>  
                </form>
                <form action="profimguploadskip.php" method="post" >
                <input type="text" style="display: none;" value="'.$me.'" name="myid">
                    <button name="skipreg" id="skipreg" type="submit">Skip</button>
                </form>
                    <label for="profimg" class="prev" id="prev">
                        <img id="profimgupl" src="default.png">
                    </label>
            </div>
        </div>';
        if(/*$_SESSION['status'] != 'New' &&*/ $nr == "none"){
        echo '<div class="selector">';
        if($result->num_rows>0){
                while($row = $result-> fetch_assoc()){
                    if(($row["fname"]!= $_SESSION["fname"] or $row["lname"]!= $_SESSION["lname"]) and $row["img"]!="settings.png")
                    {
                    echo '<div class="profile">
                    <form action="changeview.php" method="post">
                    <button type="submit" name="link" value="'.$row["unique_id"].'" style="background:none; border:none; width:fit-content; height:fit-content;";
                    <button type="submit" style="width:auto; height:auto; background:transparent; display:inline-flex;"><img src="profile/'.$row["img"].'" alt="">
                    <div class="usinf">
                        <h1>'.$row["fname"].' '.$row["lname"].'</h1>
                        <p>Click here to open chat</p>
                    </div></button></form>
                    <!--<button class="addf" style="cursor:not-allowed;" disabled>Add friend</button></button>-->
                    </div>';}
                }
        echo '</div>';
            }}
        if(/*$_SESSION['status'] != 'New' &&*/ $nr != "none"){
        echo '
        <div class="chat" id="chat" onload="reloadChat">
            '?>
            <?php include 'chatcontent.php'; ?>
            <?php echo'
        </div>
        ';}?>
        <div class="notifwindow" id="notifwindow">
            <form class="notifmsg" id="new">
                <button class="notifmsg">
                    <img src="default.png" alt="">
                    <h1>Szel Akos Istvan</h1>
                    <p>Last message from Szel..</p>
                </button>
            </form>
            <form class="notifmsg" id="viewed">
                <button class="notifmsg">
                    <img src="default.png" alt="">
                    <h1>Szel Akos Istvan</h1>
                    <p>Last message from Szel..</p>
                </button>
            </form>
            <form class="notifmsg" id="viewed">
                <button class="notifmsg">
                    <img src="default.png" alt="">
                    <h1>Szel Akos Istvan</h1>
                    <p>Last message from Szel..</p>
                </button>
            </form>
            <form class="notifmsg" id="viewed">
                <button class="notifmsg">
                    <img src="default.png" alt="">
                    <h1>Szel Akos Istvan</h1>
                    <p>Last message from Szel..</p>
                </button>
            </form>
            <form class="notifmsg" id="viewed" style="display:flex;justify-content=center;align-items:center;font-family: 'Mitr', sans-serif;font-size:12px;">
                <button class="notifmsg">
                    <h1>Hello New User </h1>
                </button>
            </form>
        </div>
        <div class="settings" id="settings">
            <ul>
                <!--<li>
                    <input type="checkbox" id="switch" onclick="twofa()"/><label for="switch" id="forswitch"></label>
                    <h2>2FA</h2>
                </li>
                <li>
                    <button>
                        Change prof img
                    </button>
                </li>-->
                <li>
                    <form action="logout.php">
                        <button>
                            Log out
                        </button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
    <script>
        document.getElementById("blahx").checked = false;
        document.getElementById("blahy").checked = false;
        document.getElementById("sendimage").style.display = "none";
        document.getElementById("sendfile").style.display = "none";
        document.getElementById("sendmtmsg").style.display = "none";
        function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
            $('#blah').attr('src', e.target.result).height(90);
            document.getElementById("blahx").checked = true;
            if(document.getElementById("blahx").checked == true)
            {
                document.getElementById("sendimage").style.display = "flex";
                document.getElementById("sendfile").style.display = "none";
                document.getElementById("text").style.display = "none";
                document.getElementById("sendmtmsg").style.display = "none";
            }
            };
            

            reader.readAsDataURL(input.files[0]);
        }
        }
        function readFILE(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
            $('#filename').attr('value', e.target.result);
            document.getElementById("blahy").checked = true;
            if(document.getElementById("blahy").checked == true)
            {
                document.getElementById("sendimage").style.display = "none";
                document.getElementById("sendfile").style.display = "flex";
                document.getElementById("text").style.display = "none";
                document.getElementById("sendmtmsg").style.display = "none";
            }
            };
            

            reader.readAsDataURL(input.files[0]);
        }
        }
        function returntowritre(){
            document.getElementById("blahy").checked = false;
            document.getElementById("blahx").checked = false;
            document.getElementById("sendimage").style.display = "none";
            document.getElementById("sendfile").style.display = "none";
            document.getElementById("text").style.display = "flex";
            document.getElementById("sendmtmsg").style.display = "none";
            $(`#filename`).attr(`value`, "");
            $(`#blah`).attr(`src`, "#");
        }
        function openreactionmenu(){
            if(document.getElementById("reactionmenu").style.display == "grid"){
            document.getElementById("reactionmenu").style.display = "none";}
            else{
            document.getElementById("reactionmenu").style.display = "grid";
            document.getElementById("sendmtmsg").style.display = "none";}
        }
        function sendmoji(param){
            event = event || window.event;
            var source = event.target || event.srcElement;
            var moji = (param);
            //console.log(moji);
            var text = document.getElementById("write").value;
            //console.log(text);
            var oImg=document.createElement("img");
            oImg.src=moji;
            param=param.slice(0, -4);
            //document.getElementById("textt").appendChild(oImg);
            if(param=="laughing")
            param = "😆";
            if(param=="happy")
            param = "🙂";
            if(param=="cute")
            param = "😢";
            if(param=="likeeye")
            param = "😍";
            if(param=="crazy")
            param = "😛";
            if(param=="shocked")
            param = "😨";
            if(param=="angry")
            param = "😡";
            if(param=="sad")
            param = "😕";
            if(param=="wink")
            param = "😉";
            if(param=="heart")
            param = "❤";
            document.getElementById("write").value= text + " "+ /*"<img src='"+moji+"'>"*/ param ;
            //console.log(param);
        }
        window.onload=function () {
            var objDiv = document.getElementById("chat");
            objDiv.scrollTop = objDiv.scrollHeight;
            if(document.getElementById("blahx").checked == false)
                document.getElementById("sendimage").style.display = "none";
                document.getElementById("sendfile").style.display = "none";
        }
        //eddig kaka vagy idk
        var write = document.getElementById("write");
        window.onload=function () {
            var objDiv = document.getElementById("chat");
            write.focus();
            objDiv.scrollTop = objDiv.scrollHeight;
        }
        window.setInterval(`refresh()`, 1000);
        function refresh() {    
            if(document.activeElement === write)
                {
                    $("#refr").load(location.href + " #refr");
                    var objDiv = document.getElementById("chat");
                    objDiv.scrollTop = objDiv.scrollHeight;
                }
            /*$(document).mouseover(function(event) {
                if (event.target.id == "chat") {
                    $("body").css("background-color", "red"); //over the div so change the color
                    return;
                }
                $("body").css("background-color", "green"); //no on the div
            });*/
        }
        /*var msnr = JSON.parse(localStorage.getItem("msnr"));
        document.getElementById("notification").insertAdjacentText('beforeend', msnr);
        if(msnr=="0")
        {document.getElementById("notification").style.display="none";}*/
        function hidesettings(){
            if(document.getElementById("settings").style.display == "block"){
            document.getElementById("settings").style.display = "none";}
            else{
            document.getElementById("settings").style.display = "block";
            document.getElementById("notifwindow").style.display = "none";}
        }
        function hidenotifs(){
            if(document.getElementById("notifwindow").style.display == "block"){
            document.getElementById("notifwindow").style.display = "none";
            document.getElementById("new").setAttribute(`id`,`viewed`);}
            else{
            document.getElementById("notifwindow").style.display = "block";
            document.getElementById("settings").style.display = "none";
            /*document.getElementById("notification").style.display="none";
            localStorage.setItem("msnr", 0);*/}
        }
        function hidemmsg() {
            if(document.getElementById("sendmtmsg").style.display == "flex"){
            document.getElementById("sendmtmsg").style.display = "none";}
            else{
            document.getElementById("sendmtmsg").style.display = "flex";
            document.getElementById("reactionmenu").style.display = "none";}
        }
        function twofa(){
        if(document.getElementById("switch").checked == true){
            twfa="checked";
            localStorage.setItem("twofa", document.getElementById("switch").checked);
            document.getElementById("forswitch").style.cursor="not-allowed";
            }
        if(document.getElementById("switch").checked == false){
            twfa="unchecked";}
        }
        var checked = JSON.parse(localStorage.getItem("twofa"));
        document.getElementById("switch").checked = checked;
        if(document.getElementById("switch").checked == true){
        document.getElementById("forswitch").style.cursor="not-allowed";}
        document.getElementById("profimgupl").addEventListener("change",()=>{
            document.getElementById("profimgupl").src=URL.createObjectURL(document.getElementById("profimg").files[0]);
            console.log('"'+document.getElementById("profimg").value+'"');
        });
        



        
    </script>
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
</body>
</html>
<?php
}else{
    header("Location: login");
    exit();
}
?>