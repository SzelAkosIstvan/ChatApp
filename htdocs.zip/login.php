<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messenger-login</title>
    <link rel="stylesheet" href="login.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
</head>
<body>
    <img src="nightcall.svg" id="bg">
    <div class="layer">
        <header>
            <div style="display: flex;margin-top: 50px;">
                <img style="width: 50px;height: 50px;" src="output-onlinepngtools.png"/>
                <h1>Chat</h1>
            </div>
            <!--<ul>
                <li>
                    <a href="https://www.google.com">
                        Home
                    </a>
                </li>
                <li>
                    <a href="register.html">
                        Join
                    </a>
                </li>
            </ul>-->
        </header>
        <div class="befandform" style="margin-top: 150px;">
        <p>Start chatting with your friends</p>
        <h1>Let`s sign you in<font color="#6C63FF">.</font></h1>
        <p>You don't have an account? <a href="register.php">Register</a></p>
        <form action="auth.php" method="post" autocomplete="off">
            <div style="display: grid;width: 406px;">
                <input type="email" name="email" id="email" placeholder="Email">
                <img src="email.svg" style="position: absolute;margin-top: 13px;margin-left: 12px;width: 20px;">
                <input type="password" name="password" id="pass"  placeholder="Password">
                <img src="lock.svg" style="position: absolute;margin-top: 80px;margin-left: 12px;width: 20px;">
                <img onclick="TogglePasswordVisibility()" src="eye-svgrepo-com.svg" style="position: absolute;margin-top: 80px;margin-left: 410px;width: 20px;cursor: pointer;">
            </div>
            <div style="display: flex;width: 450px;justify-content: space-between;margin-top: 30px;">
                <button id="change" formaction="register.php">Change method</button>
                <button id="create" type="submit">Login</button>
            </div>
        </form>
        </div>
    </div>
    <footer></footer>
    <script src="auth.js"></script>
    <script>
        function TogglePasswordVisibility() {
        var x = document.getElementById("pass");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
        }
    </script>
</body>
</html>
<!-- action="auth.php" method="post"  type="submit" -->