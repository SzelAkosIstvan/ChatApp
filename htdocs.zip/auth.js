const form = document.querySelector(".layer form"),
loginBtn = form.querySelector("#create");

form.onsubmit = (e)=>{
    e.preventdefault();
}

loginBtn.onclick = ()=>{
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "auth.php", true);
    xhr.onload = ()=>{
        if(xhr.readyState === XMLHttpRequest.DONE){
            if(xhr.status === 200){
                let data = xhr.response;
                console.log(data)
            }
        }
    }
    xhr.send();
}
/*<?php

    include_once "db.php";
    $email= mysqli_real_escape_string($conn, $_POST['email']);
    $password= mysqli_real_escape_string($conn, $_POST['password']);

    if(!empty($email) && !empty($password)){
        
    }
?> */