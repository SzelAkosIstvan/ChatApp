<?php
session_start();
include "db.php";
    if (isset($_POST['email']) && isset($_POST['password'])){
        function validate($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        $umail = validate($_POST['email']);
        $upass = validate($_POST['password']);
        if(empty($umail)){
            header("Location: login.php?error=Email is requred");
            exit();
        }else if(empty($upass)){
            header("Location: login.php?error=Password is requred");
            exit();
        }else{
            $upass=md5($upass);
            $sql = "SELECT * FROM users WHERE email='$umail' and password='$upass'";
            $result = mysqli_query($conn, $sql);
            if(mysqli_num_rows($result) === 1){
                $row = mysqli_fetch_assoc($result);
                if($row['email']===$umail && $row['password']===$upass){
                    $_SESSION['user_id'] = $row['user_id'];
                    $_SESSION['unique_id'] = $row['unique_id'];
                    $_SESSION['fname'] = $row['fname'];
                    $_SESSION['lname'] = $row['lname'];
                    $_SESSION['img'] = $row['img'];
                    $_SESSION['status'] = $row['status'];
                    $_SESSION['chat'] = "none";
                    //ida add hozza a tobbi szart
                    header("Location: index.php");
                    exit();
                }else{
                    header("Location: register.php");
                    exit();
                }
            }else{
                header("Location: register.php");
                exit();
            }
        }
    }else{
        header("Location: register.php");
        exit();
    }
?>