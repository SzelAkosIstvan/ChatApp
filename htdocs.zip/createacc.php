<?php
session_start();
include "db.php";
    if (isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['email']) && isset($_POST['password'])){
        function validate($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        $fname = validate($_POST['fname']);
        $lname = validate($_POST['lname']);
        $umail = validate($_POST['email']);
        $upass = validate($_POST['password']);
        $uuniqueid = random_int(100, 9999);
        $umg = "settings.png";
        $ustats = "New";
        $user_data='fname='.$fname.'&lname='.$lname;
        if(empty($fname)){
            header("Location: register.php?error=Firs Name is requred");
            exit();
        }else if(empty($lname)){
            header("Location: register.php?error=Last Name is requred");
            exit();
        }else if(empty($umail)){
            header("Location: register.php?error=Email is requred");
            exit();
        }else if(empty($upass)){
            header("Location: register.php?error=Password is requred");
            exit();
        }else{
            $upass=md5($upass);
            $sql = "SELECT * FROM users WHERE email='$umail'";
            $result = mysqli_query($conn, $sql);
            if(mysqli_num_rows($result) > 0){
                header("Location: register.php?error=Email is taken");
                exit();
            }else{
                $sql2="INSERT INTO users(unique_id,fname,lname,email,password,img,status) VALUES('$uuniqueid','$fname','$lname','$umail','$upass','$umg','$ustats')";
                $result2 = mysqli_query($conn, $sql2);
                if($result2){
                        $result = mysqli_query($conn, $sql);
                        if(mysqli_num_rows($result) === 1){
                        $row = mysqli_fetch_assoc($result);
                            if($row['email']===$umail && $row['password']===$upass){
                    $_SESSION['user_id'] = $row['user_id'];
                    $_SESSION['unique_id'] = $row['unique_id'];
                    $_SESSION['fname'] = $row['fname'];
                    $_SESSION['lname'] = $row['lname'];
                    $_SESSION['img'] = $row['img'];
                    $_SESSION['status'] = $row['status'];
                    $_SESSION['chat'] = "none";
                    header("Location: index.php");
                    exit();
                    }else{
                        header("Location: register.php?error=aaaaahj");
                        exit();
                    }
                    }
                }else{
                    header("Location: register.php?error=Email is taken");
                    exit();
                }
            }
        }
    }else{
        header("Location: login.php");
        exit();
    }
?>