<?php
session_start();
$_SESSION['chat']= "none";
$_SESSION['status']= "Done";
include "db.php";
if(isset($_POST['myid'])){
    $me = $_SESSION['unique_id'];
    $updateqry="UPDATE `users` SET `img`='defaut.png',`status`='Done' WHERE `unique_id`='$me'";
    mysqli_query($conn, $updateqry);
    header('Location: index.php');
}
?>