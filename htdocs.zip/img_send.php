<?php
session_start();
include "db.php";
if(isset($_POST['myid']))
{
    $extension=array('jpeg', 'jpg', 'png', 'gif');
        $filename=$_FILES['your_img']['name'];
        $filename_tmp=$_FILES['your_img']['tmp_name'];
        $ext=pathinfo($filename,PATHINFO_EXTENSION);
        
        $finalimg='';
        if(in_array($ext, $extension)){
            if(!file_exists('images/'.$filename)){
            move_uploaded_file($filename_tmp, 'images/'.$filename);
            $finalimg=$filename;
            }else{
                $filename=str_replace('.','-',basename($filename,$ext));
                $newfilename=$filename.time().".".$ext;
                move_uploaded_file($filename_tmp, 'images/'.$newfilename);
                $finalimg=$newfilename;
            }
            function validate($data){
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }
            $m_name = validate($_POST['myid']);
            $f_name = validate($_POST['friendid']);
            $time_temp = date("Y m d/h:i:sa");
            $insertqry="INSERT INTO message(msg_from, msg_to, msg_information, msg_time) VALUES('$m_name','$f_name','$finalimg','$time_temp')";
            mysqli_query($conn, $insertqry);
            header('Location: index.php');
        }else{

        }
    }
?>