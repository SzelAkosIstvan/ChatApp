<?php
session_start();
$_SESSION['chat']= $_POST['link'];
header("Location: index.php");
exit();
?>