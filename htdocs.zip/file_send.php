<?php
session_start();
include "db.php";
if(isset($_POST['myid']))
{
        $filename=$_FILES['your_file']['name'];
        $filename_tmp=$_FILES['your_file']['tmp_name'];
        $ext=pathinfo($filename,PATHINFO_EXTENSION);
        
        $finalfile='';
            if(!file_exists('files/'.$filename)){
            move_uploaded_file($filename_tmp, 'files/'.$filename);
            $finalfile=$filename;
            }else{
                $filename=str_replace('.','-',basename($filename,$ext));
                $newfilename=$filename.time().".".$ext;
                move_uploaded_file($filename_tmp, 'files/'.$newfilename);
                $finalfile=$newfilename;
            }
            function validate($data){
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }
            $m_name = validate($_POST['myid']);
            $f_name = validate($_POST['friendid']);
            $time_temp = date("Y m d/h:i:sa");
            $insertqry="INSERT INTO message(msg_from, msg_to, msg_information, msg_time) VALUES('$m_name','$f_name','$finalfile','$time_temp')";
            mysqli_query($conn, $insertqry);
            header('Location: index.php');
        }else{

        }
?>