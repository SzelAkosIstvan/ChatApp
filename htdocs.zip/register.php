<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messenger-register</title>
    <link rel="stylesheet" href="register.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
</head>
<body>
    <img src="chatting.svg" id="bg">
    <div class="layer">
        <header>
            <div style="display: flex;margin-top: 50px;">
                <img style="width: 50px;height: 50px;" src="output-onlinepngtools.png"/>
                <h1>Chat</h1>
            </div>
            <!--<ul>
                <li>
                    <a href="https://www.google.com">
                        Home
                    </a>
                </li>
                <li>
                    <a href="login.php">
                        Join
                    </a>
                </li>
            </ul>-->
        </header>
        <div class="befandform" style="margin-top: 150px;">
        <p>Start chatting with your friends</p>
        <h1>Create new account<font color="#6C63FF">.</font></h1>
        <p>Already a member? <a href="login.php">Log In</a></p>
        <form action="createacc.php" method="post" autocomplete="off">
            <div style="display: flex;width: 450px;justify-content: space-between;">
                <input type="text" id="fname" name="fname" placeholder="First name">
                <img src="contact-svgrepo-com.svg" style="position: absolute;margin-top: 11px;margin-left: 10px;">
                <input type="text" id="lname" name="lname" placeholder="Last name">
                <img src="contact-svgrepo-com.svg" style="position: absolute;margin-top: 11px;margin-left: 245px;">
            </div>
            <div style="display: grid;width: 406px;">
                <input type="email" id="email" name="email" placeholder="Email">
                <img src="email.svg" style="position: absolute;margin-top: 13px;margin-left: 12px;width: 20px;">
                <input type="password" id="pass" name="password" placeholder="Password">
                <img src="lock.svg" style="position: absolute;margin-top: 80px;margin-left: 12px;width: 20px;">
                <img onclick="TogglePasswordVisibility()" src="eye-svgrepo-com.svg" style="position: absolute;margin-top: 80px;margin-left: 410px;width: 20px;cursor: pointer;">
            </div>
            <div style="display: flex;width: 450px;justify-content: space-between;margin-top: 30px;">
                <button id="change" formaction="login.php">Change method</button>
                <button id="create">Create account</button>
            </div>
        </form>
        </div>
    </div>
    <footer></footer>
    <script>
        function TogglePasswordVisibility() {
        var x = document.getElementById("pass");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
        }
    </script>
</body>
</html>